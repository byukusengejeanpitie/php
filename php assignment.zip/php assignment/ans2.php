<?php
$weight = 70;  
$height = 2;
$bmi = $weight / ($height * $height);
echo "Your BMI is: " .$bmi;
?>
