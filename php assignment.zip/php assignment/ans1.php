<?php
$length = 10;
$width = 5;  
$area = $length * $width;
echo "The area of the rectangle is: " . $area;
?>
